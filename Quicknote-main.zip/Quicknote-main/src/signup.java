import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/SignupServlet")
public class signup extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String username = request.getParameter("username");
        String password = request.getParameter("pass");

        // Logging input for debugging
        System.out.println("Received username: " + username);
        System.out.println("Received password: " + password);

        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;

        try {
            // Connect to the database
            Class.forName("com.mysql.cj.jdbc.Driver");
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/quicknote", "root", "heloworld1");
            System.out.println("Database connection established.");

            // Check if the username already exists
            String checkUserQuery = "SELECT username FROM users WHERE username = ?";
            stmt = conn.prepareStatement(checkUserQuery);
            stmt.setString(1, username);
            rs = stmt.executeQuery();

            if (rs.next()) {
                // Username already exists
                System.out.println("Username already exists: " + username);
                request.setAttribute("message", "Username is already taken. Please choose another.");
                request.getRequestDispatcher("signup.jsp").forward(request, response);
            } else {
                // Insert the new user into the database
                String insertUserQuery = "INSERT INTO users (username, password) VALUES (?, ?)";
                stmt = conn.prepareStatement(insertUserQuery);
                stmt.setString(1, username);
                stmt.setString(2, password); // Store hashed password in production
                stmt.executeUpdate();

                System.out.println("User registered successfully: " + username);

                // Redirect to login page with success
                response.sendRedirect("Login.jsp?success=1");
            }
        } catch (Exception e) {
            e.printStackTrace();
            request.setAttribute("message", "An error occurred. Please try again.");
            request.getRequestDispatcher("signup.jsp").forward(request, response);
        } finally {
            // Close resources
            try {
                if (rs != null) rs.close();
                if (stmt != null) stmt.close();
                if (conn != null) conn.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
}
